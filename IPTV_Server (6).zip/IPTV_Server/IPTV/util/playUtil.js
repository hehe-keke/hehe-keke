const axios = require('axios');
const fs = require('fs');
const path = require('path');
const https = require('https');
const tough = require('tough-cookie');
const { wrapper } = require('axios-cookiejar-support');

// 创建一个 CookieJar 实例
const cookieJar = new tough.CookieJar();
const client = wrapper(axios.create({ jar: cookieJar, withCredentials: true }));

// 全局变量，存储频道信息对象
global.channelInfoObj = {};

// 获取当前时间戳（秒）
const getCurrentTimestampInSeconds = () => Math.floor(Date.now() / 1000);


const randomUserAgent = () => {
    const devices = ['iPhone', 'iPad', 'Android', 'Windows Phone'];
    const browsers = ['Chrome', 'Firefox', 'Safari', 'Opera'];
    const randomDevice = devices[Math.floor(Math.random() * devices.length)];
    const randomBrowser = browsers[Math.floor(Math.random() * browsers.length)];
    return `Mozilla/5.0 (Linux; U; ${randomDevice}; zh-cn; M2007J17C Build/SKQ1.211006.001) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 ${randomBrowser}/109.0.5414.118 Mobile Safari/537.36 XiaoMi/MiuiBrowser/17.9.111128 swan-mibrowser`;
};


// 更新频道信息
const updateChannelInfo = (category, channel, videoUrl) => {
    // 如果该分类不存在，则初始化为空数组
    if (!channelInfoObj[category]) {
        channelInfoObj[category] = [];
    }

    // 查找现有的频道
    const existingChannels = channelInfoObj[category].filter(item => item.channel === channel);

    // 优先更新 `videoUrl` 为空的条目
    const emptyUrlChannel = existingChannels.find(item => !item.videoUrl);
    if (emptyUrlChannel) {
        emptyUrlChannel.videoUrl = videoUrl;
        global.logger.info(`${channel}, ${videoUrl} 数据更新成功`);
    } else if (existingChannels.length > 0) {
        // 如果没有找到 `videoUrl` 为空的条目，但找到了其他条目，则不进行任何操作
        global.logger.info(`${channel}, ${videoUrl} 已经存在于该频道`);
    } else {
        // 如果频道不存在，则创建新的条目
        channelInfoObj[category].push({ channel: channel, videoUrl: videoUrl });
        global.logger.info(`${channel}, ${videoUrl} 数据添加成功`);
    }

    global.logger.debug(`updateChannelInfo \n: ${JSON.stringify(channelInfoObj[category], null, 2)}`);
};




// 获取指定键的 Cookie 值
const getCookieValue = async (key) => {
    const url = 'http://tonkiang.us/?';
    const formData = new URLSearchParams({
        seerch: '广东卫视',
        Submit: '+',
        name: 'NjU1Nzkz',
        city: 'MzU3NDI5NTE2NDAya2tr',
    });

    try {
        const response = await client.post(url, formData.toString(), {
            headers: {
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': randomUserAgent(),
                'Origin': 'http://tonkiang.us',
                'Referer': 'http://tonkiang.us/?',
            },
            maxRedirects: 1,
        });

        const setCookieHeaders = response.headers['set-cookie'] || [];
        const firstCookie = setCookieHeaders
            .map(cookieStr => tough.Cookie.parse(cookieStr))
            .find(cookie => cookie && cookie.key === key);

        const cookieValue = firstCookie ? firstCookie.value : null;
        global.logger.info(`First ${key} value:`, cookieValue);
        return cookieValue;
    } catch (error) {
        global.logger.error('获取 Cookie 失败:', error.message);
        return null;
    }
};

// 发送 GET 请求
const sendGetRequest = async (url, headers, retryCount = 3, errTime = 300000, timeout = 5000) => {
    for (let attempt = 0; attempt < retryCount; attempt++) {
        try {
            const response = await axios.get(url, { headers, timeout });
            if (response.status === 200) {
                return response.data;
            } else {
                throw new Error('Non-200 status code');
            }
        } catch (error) {
            if (attempt < retryCount - 1) {
                await new Promise(resolve => setTimeout(resolve, errTime));
            } else {
                global.logger.warn(`${url}: 所有重试失败. 返回 null.`);
                return null;
            }
        }
    }
};

// 将字符串格式化为对象
const formatStringToObject = (inputString) => {
    const targetObject = {};
    const lines = inputString.split(/\r?\n/);
    let categories = [];

    for (const line of lines) {
        const trimmedLine = line.trim();
        if (!trimmedLine) continue;

        if (trimmedLine.includes('#genre#')) {
            categories = trimmedLine.split(',').slice(0, -1); // 删除最后一个元素
            categories.forEach(category => {
                targetObject[category] = [];
            });
        } else if (trimmedLine.includes(',')) {
            const [channel, url] = trimmedLine.split(',');
            categories.forEach(category => {
                targetObject[category].push({ channel: channel.trim(), videoUrl: url.trim() });
            });
        }
    }

    categories.forEach(category => {
        if (!targetObject[category] || targetObject[category].length === 0) {
            targetObject[category] = [];
        }
    });

    return targetObject;
};

// 获取当前时间的格式化字符串
const getFormattedDateTime = () => {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = String(currentDate.getMonth() + 1).padStart(2, '0');
    const day = String(currentDate.getDate()).padStart(2, '0');
    return `${year}${month}${day}`;
};

const checkUrlStatus = async (url, retryCount = global.config.checkUrlRetryCount, timeout = global.config.timeout.checkUrl) => {
    for (let i = 0; i < retryCount; i++) {
        const startTime = Date.now();
        try {
            const response = await axios({
                method: url.startsWith('https') ? 'post' : 'get',
                url: url,
                timeout: timeout,
                maxRedirects: 1,
                maxContentLength: 1 * 1024 * 1024, // 设置最大响应内容为 1 MB
                maxBodyLength: 1 * 1024 * 1024,    // 如果有请求主体，设置最大上传大小为 1 MB
                transformResponse: [],
                headers: { 'User-Agent': randomUserAgent() },
            });

            const endTime = Date.now();
            const responseTime = endTime - startTime;

            // 只在状态码为200时返回成功
            if (response.status === 200) {
                global.logger.info(`请求成功， ${url}: ${responseTime} ms`);
                return { success: true, statusCode: response.status, responseTime: responseTime };
            } else {
                global.logger.warn(`请求失败，状态码: ${response.status}， ${url}`);
                return { success: false, statusCode: response.status, responseTime: responseTime };
            }
        } catch (error) {
            const endTime = Date.now();
            const responseTime = endTime - startTime;

            global.logger.error(`请求错误，原因: ${url} ${error.message}`);

            const isTimeout = error.code === 'ECONNABORTED';
            return {
                success: false,
                statusCode: error.response ? error.response.status : null,
                responseTime: isTimeout ? Infinity : responseTime
            };
        }
    }

    // 尝试次数结束后，返回失败
    return { success: false, statusCode: null, responseTime: Infinity };
};


const rearrangeChannelData = async (channelData) => {
    const rearrangedData = {};
    
    // 遍历每个分类
    for (const category of Object.keys(channelData)) {
        rearrangedData[category] = {}; // 初始化当前分类的数据

        // 准备任务数组，检查每个频道的 URL 状态
        const tasks = channelData[category].map((channelObj) => {
            return async () => {
                try {
                    const response = await checkUrlStatus(channelObj.videoUrl);
                    channelObj.responseTimeInMs = response.responseTime;
                } catch (error) {
                    global.logger.info(`Error checking URL status for ${channelObj.videoUrl}: ${error}`);
                    channelObj.responseTimeInMs = Infinity; // 标记为无效
                }

                // 初始化频道数组
                if (!rearrangedData[category][channelObj.channel]) {
                    rearrangedData[category][channelObj.channel] = [];
                }

                // 检查是否为重复的 URL
                const isDuplicate = rearrangedData[category][channelObj.channel].some(
                    existingChannel => existingChannel.videoUrl === channelObj.videoUrl
                );

                // 只有在不存在相同 URL 时，才添加到数组中
                if (!isDuplicate) {
                    rearrangedData[category][channelObj.channel].push(channelObj);
                }
            };
        });

        // 控制并发执行任务
        await withConcurrencyLimit(tasks, 20);

        // 处理每个频道的数据
        Object.keys(rearrangedData[category]).forEach(channel => {
            const channelList = rearrangedData[category][channel];

            // 如果有有效的 URL，删除所有空的 URL
            const hasValidUrl = channelList.some(item => item.videoUrl && item.videoUrl !== '');
            if (hasValidUrl) {
                rearrangedData[category][channel] = channelList.filter(item => item.videoUrl && item.videoUrl !== '');
            }

            // 对剩余条目按 `responseTimeInMs` 排序
            rearrangedData[category][channel].sort((a, b) => {
                return (a.responseTimeInMs || Infinity) - (b.responseTimeInMs || Infinity);
            });
        });

        // 将频道对象转换为数组
        rearrangedData[category] = [].concat(...Object.values(rearrangedData[category]));
    }

    return rearrangedData;
};



const withConcurrencyLimit = async (tasks, limit = 5) => {
    let activePromises = 0; // 当前活跃的任务数
    const taskQueue = [...tasks]; // 将任务队列复制一份

    const results = []; // 存储任务结果
    const runTask = async (task) => {
        activePromises++;
        try {
            const result = await task(); // 执行任务
            results.push(result); // 保存任务结果
        } catch (error) {
            console.error(`任务失败: ${error.message}`);
        } finally {
            activePromises--; // 任务完成后减少活跃任务数
            if (taskQueue.length > 0) {
                // 如果队列中还有任务，继续执行下一个任务
                const nextTask = taskQueue.shift();
                runTask(nextTask);
            }
        }
    };

    // 启动初始任务，最多不会超过并发限制
    const initialTasks = Math.min(limit, taskQueue.length);
    for (let i = 0; i < initialTasks; i++) {
        const task = taskQueue.shift();
        runTask(task);
    }

    // 等待所有任务完成
    while (activePromises > 0 || taskQueue.length > 0) {
        await new Promise(resolve => setTimeout(resolve, 50)); // 小的延迟等待任务完成
    }

    console.log("线程任务已完成")
};



// 使用并发限制处理频道信息
const processChannels = async (channels, filter = global.config.urlHealthCheckEnabled) => {
    const promises = Object.keys(channels).map(async category => {
        let categoryResult = `${category},#genre#\n`;

        // 存储每个频道的结果
        const channelResults = {};

        // 处理频道列表的任务
        const tasks = channels[category].map(item => async () => {
            if (item.channel && item.channel.trim() !== '') {
                // 初始化频道结果容器
                if (!channelResults[item.channel]) {
                    channelResults[item.channel] = {
                        validUrls: [],
                        invalidUrls: []
                    };
                }

                if (filter) {
                    const result = await checkUrlStatus(item.videoUrl);
                    if (result.success) {
                        // 验证成功的 URL
                        channelResults[item.channel].validUrls.push(item.videoUrl);
                    } else {
                        // 验证失败的 URL
                        channelResults[item.channel].invalidUrls.push(item.videoUrl);
                    }
                } else {
                    // 如果不需要过滤，直接将 URL 视为有效
                    channelResults[item.channel].validUrls.push(item.videoUrl);
                }
            }
        });

        // 使用并发限制来执行任务，限制为一次最多并发 10 个任务
        await withConcurrencyLimit(tasks, 10);

        // 生成分类结果
        for (const [channel, { validUrls, invalidUrls }] of Object.entries(channelResults)) {
            if (validUrls.length > 0) {
                // 如果有多个可用 URL，每个 URL 显示在不同的行
                validUrls.forEach(url => {
                    categoryResult += `${channel},${url}\n`;
                });
            } else {
                // 如果没有可用 URL，显示频道名和空 URL
                categoryResult += `${channel},\n`;
            }
        }

        return categoryResult;
    });

    const results = await Promise.all(promises);
    return results.join('');
};



const getRelativeFilePath = (relativePath) => {
    return path.join(process.cwd(), relativePath);
};

// 写入 M3U8 文件
const writeM3u8File = (relativeFilePath, content) => {
    const filePath = getRelativeFilePath(relativeFilePath);

    if (typeof filePath !== 'string' || typeof content !== 'string') {
        global.logger.error(' 写入文件失败 filePath 和 content 必须为字符串类型');
        return;
    }

    const directory = path.dirname(filePath);

    // 检查目录是否存在，若不存在则创建
    if (!fs.existsSync(directory)) {
        fs.mkdirSync(directory, { recursive: true });
    }

    // 写入内容到文件
    fs.writeFileSync(filePath, content, 'utf8');
    global.logger.info(`成功写入文件 ${filePath}`);
};

// 读取 M3U8 文件
const readM3u8File = (relativeFilePath) => {
    const filePath = getRelativeFilePath(relativeFilePath);

    if (typeof filePath !== 'string') {
        global.logger.error('读取文件失败 filePath 必须为字符串类型');
        return null;
    }

    try {
        // 检查文件是否存在，不存在则创建空文件
        if (!fs.existsSync(filePath)) {
            fs.writeFileSync(filePath, '', 'utf8');
            global.logger.info(`成功创建文件 ${filePath}`);
        }

        // 读取文件内容
        const content = fs.readFileSync(filePath, 'utf8');
        global.logger.info(`成功读取文件 ${filePath}`);
        return content;
    } catch (err) {
        global.logger.error(`读取文件 ${filePath} 失败: ${err.message}`);
        return null;
    }
};

// 导出模块
module.exports = {
    checkUrlStatus,
    updateChannelInfo,
    getCookieValue,
    sendGetRequest,
    formatStringToObject,
    getFormattedDateTime,
    rearrangeChannelData,
    processChannels,
    writeM3u8File,
    readM3u8File,
    getCurrentTimestampInSeconds,
    randomUserAgent,
    withConcurrencyLimit
};
