const cheerio = require('cheerio');
const playUtil = require('./util/playUtil');



let cookieREFERER;

async function preloadREFERER() {
    cookieREFERER = await playUtil.getCookieValue('REFERER');
}

async function fetchPage(url, headers) {
    try {
        return await playUtil.sendGetRequest(url, headers, global.config.checkUrlRetryCount, global.config.timeout.fetchPageErr, global.config.timeout.fetchPage);
    } catch (error) {
        global.logger.error(`Failed to fetch URL ${url}:`, error);
        return null; 
    }
}

async function searchIPTVProgram(pageNumber, programName) {
    const searchResults = new Set();
    const encodedProgramName = encodeURIComponent(programName);
    const headers = {
        'User-Agent': playUtil.randomUserAgent(),
        'Cookie': `_ga=GA1.1.${playUtil.getCurrentTimestampInSeconds()}.${playUtil.getCurrentTimestampInSeconds()}; REFERER=${cookieREFERER};`,
    };

    await fetchWithConcurrencyLimit(pageNumber, encodedProgramName, headers, searchResults, global.config.fetchPageCount);
    return Array.from(searchResults);
}

async function fetchWithConcurrencyLimit(pageNumber, encodedProgramName, headers, searchResults, limit) {
    const promises = [];
    let currentPage = 1;

    while (currentPage <= pageNumber) {
        if (promises.length >= limit) {
            await handlePageResults(promises, searchResults);
        }
        promises.push(fetchPage(`http://tonkiang.us/?page=${currentPage++}&iptv=${encodedProgramName}`, headers));
    }

    // 处理剩余未完成的请求
    if (promises.length) {
        await handlePageResults(promises, searchResults);
    }
}

async function handlePageResults(promises, searchResults) {
    const results = await Promise.all(promises);
    const uniqueUrls = new Set();

    results.forEach(result => {
        if (result) {
            const urls = extractUrlsByChannel(result);
            urls.forEach(url => uniqueUrls.add(url));
        }
    });

    uniqueUrls.forEach(url => searchResults.add(url));
}

function extractUrlsByChannel(html) {
    const $ = cheerio.load(html);
    const resultList = new Set(); 

    $('div.resultplus').each((index, resultElement) => {
        const channelText = $(resultElement).find('div.channel').text().trim();
        const channelUrl = $(resultElement).find('div tba').text().trim(); 
        if (channelText && channelUrl) {
            resultList.add({ channel: channelText, videoUrl: channelUrl });
        }
    });
    global.logger.debug(`extractUrlsByChannel \n: ${resultList}`)
    return Array.from(resultList); 
}

async function processChannel(group, channel, visitedChannels) {
    if (!visitedChannels.has(channel.channel)) {
        visitedChannels.add(channel.channel);
        try {
            const htmlChannels = await searchIPTVProgram(2, channel.channel);
            await checkUrlsForChannels(group, htmlChannels);
        } catch (error) {
            global.logger.error(`搜索 IPTV 频道 ${channel.channel} 失败:`, error);
        }
    }
}

async function checkUrlsForChannels(group, htmlChannels) {
    const channelChecks = htmlChannels.map(async (htmlChannel) => {
        try {
            const checkUrlResult = await playUtil.checkUrlStatus(htmlChannel.videoUrl);
            if (checkUrlResult.success) {
                playUtil.updateChannelInfo(group, htmlChannel.channel, htmlChannel.videoUrl);
            }
        } catch (error) {
            global.logger.error(`检查 URL ${htmlChannel.videoUrl} 失败:`, error);
        }
    });

    await Promise.all(channelChecks);
}



// 主服务器逻辑
const main_server = async (apiPath) => {
    global.logger.info('main_server 运行中');

    await preloadREFERER();
    const channelGroups = playUtil.formatStringToObject(playUtil.readM3u8File(apiPath));

    for (const group of Object.keys(channelGroups)) {
        const visitedChannels = new Set();
        const channelsInGroup = channelGroups[group];
        global.logger.info(`处理分组: ${group}`);

        // 创建任务列表
        const tasks = channelsInGroup.map(channel => async () => {
            await processChannel(group, channel, visitedChannels);
        });

        // 限制并发执行任务
        await playUtil.withConcurrencyLimit(tasks, global.config.concurrencyPageLimit,global.config.timeout.fetchPageErr);
        channelGroups[group] = []; 
        global.logger.info(`分组 ${group} 更新完成`);
    }

    global.logger.info('所有分类更新完成');
};

module.exports = { main_server };
