const express = require('express');
const app = express();
const router = express.Router();
const fs = require('fs').promises; // 使用 promises 方式直接引入 fs
const path = require('path');
const cron = require('node-cron');
const playUtil = require('./util/playUtil'); 
const { main_server } = require('./dataServer');

// 构建配置文件的绝对路径
const configPath = path.join(__dirname, 'config', 'config.json');

// 定义全局变量
global.config = {};
let renderedChannelsHTML = ''; // 用于存储生成的频道 HTML

const winston = require('winston');
// 定义日志级别及其优先级
const logLevels = {
    info: 0,
    warn: 1,
    error: 2,
    debug: 3,
    verbose: 4
};

// 创建一个 logger 实例
global.logger = winston.createLogger({
    level: global.config.logger, // 设置最低日志级别
    levels: logLevels, // 定义日志级别及其优先级
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.simple() // 使用简单的日志格式
    ),
    transports: [
        new winston.transports.Console({
            format: winston.format.combine(
                winston.format((info) => {
                    // 获取当前日志级别的优先级
                    const currentLevelPriority = logLevels[global.config.logger];
                    // 获取日志信息的优先级
                    const logLevelPriority = logLevels[info.level];
                    // 只有当日志信息的优先级小于等于当前级别时，才返回该日志
                    return logLevelPriority <= currentLevelPriority ? info : false;
                })(),
                winston.format.timestamp(),
                winston.format.simple()
            )
        })
    ]
});


async function loadConfig() {
    try {
        const data = await fs.readFile(configPath, 'utf8');
        global.config = JSON.parse(data); 
        global.logger.info('配置文件读取成功:', global.config);
    } catch (err) {
        handleConfigError(err);
    }
}

// 错误处理函数
function handleConfigError(err) {
    if (err.code === 'ENOENT') {
        global.logger.error('配置文件未找到:', configPath);
    } else if (err instanceof SyntaxError) {
        global.logger.error('配置文件格式错误:', err.message);
    } else {
        global.logger.error('读取配置文件时出错:', err);
    }
}

// 更新频道信息并生成 HTML
async function updateChannelInfo() {
    try {
        await main_server(global.config.filePaths.input);
        await saveChannelDataToFile();
        renderedChannelsHTML = await generateChannelsHTML(global.channelInfoObj);
    } catch (error) {
        global.logger.error("更新频道信息失败：", error);
    }
}

// 保存频道数据到文件
async function saveChannelDataToFile() {
    try {
        const rearrangedData = await playUtil.rearrangeChannelData(global.channelInfoObj);
        global.channelInfoObj = rearrangedData;
        // 删除空对象并重组 channelInfo
        const firstKey = Object.keys(global.channelInfoObj)[0];
        if (global.channelInfoObj[firstKey]?.length === 0) {
            delete global.channelInfoObj[firstKey];
        }

        // 添加带有当前日期时间的组标题
        global.channelInfoObj = {
            [`${playUtil.getFormattedDateTime()} 群: 719790842`]: [{}],
            ...global.channelInfoObj
        };

        const processedChannels = await playUtil.processChannels(global.channelInfoObj);
        playUtil.writeM3u8File(global.config.filePaths.output, processedChannels);
    } catch (error) {
        global.logger.error("保存频道数据失败：", error);
    }
}
//生成html
async function generateChannelsHTML(channelInfoObj) {
    let channelsHTML = '';

    for (const [category, channels] of Object.entries(channelInfoObj)) {
       
        const categoryText = `${category.replace('#genre#', 'Genre')},#genre#`;
        channelsHTML += `<p>${escapeHTML(categoryText)}</p>\n`;
        
        channels.forEach(channel => {
            
            if (channel && channel.channel && channel.VideoUrl) {
                const { channel: channelName, VideoUrl } = channel;
                channelsHTML += `<p>${escapeHTML(channelName)}`;
                channelsHTML += `, <a href="${escapeHTML(VideoUrl)}" target="_blank">${escapeHTML(VideoUrl)}</a>`;
                channelsHTML += `</p>\n`;
            } else {
                // 处理可能为空的对象
                channelsHTML += `<p>Invalid channel data</p>\n`;
            }
        });
    }
    return channelsHTML;
}


// HTML 转义函数，防止 XSS 攻击
function escapeHTML(str) {
    
    return str.replace(/&/g, '&amp;')
              .replace(/</g, '&lt;')
              .replace(/>/g, '&gt;')
              .replace(/"/g, '&quot;')
              .replace(/'/g, '&#039;');
}

// 初始化频道信息
async function initializeChannelInfo() {
    const playlistPath = global.config.filePaths.input;
    global.channelInfoObj = playUtil.formatStringToObject(playUtil.readM3u8File(playlistPath));
    await updateChannelInfo();
}

// 启动时初始化频道信息并设置定时任务
(async () => {
    await loadConfig();

    if (!global.config) {
        global.logger.error("无法加载配置文件，应用无法启动");
        process.exit(1);
    }

    //启动服务器，监听指定端口
    app.use('/', router); 
    const PORT = global.config.server.port || 3000;
    // app.listen(PORT, () => {
    //     global.logger.info(`服务器正在运行，访问 http://localhost:${PORT}${global.config.server.apiPath}`);
    // });

    // 路由处理
    router.get(global.config.server.apiPath, async (req, res) => {
        try {
            const channelHTML = await generateChannelsHTML(
                playUtil.formatStringToObject(playUtil.readM3u8File(global.config.filePaths.output))
            );
            res.send(channelHTML); // 发送生成的 HTML 响应
        } catch (error) {
            global.logger.error("处理请求时出错：", error);
            res.status(500).send("内部服务器错误");
        }
    });

    // 初始化频道信息
    await initializeChannelInfo();

    // 设置定时任务，防止重复执行
    cron.schedule(global.config.scheduledUpdatescCron || '0 * * * *', async () => {
        global.logger.info("定时任务执行中...");
        try {
            await initializeChannelInfo();
            global.logger.info("频道信息已更新。");
        } catch (error) {
            global.logger.error("定时任务执行失败：", error);
        }
    });
})();

module.exports = router;
